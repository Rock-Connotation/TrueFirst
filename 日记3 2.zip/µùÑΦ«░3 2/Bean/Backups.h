//
//  Backups.h
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//Copyright © 2020 石子涵. All rights reserved.
//

#import <Realm/Realm.h>

@interface Backups : RLMObject
@property(nonatomic, strong)NSString *date;
@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *content;

@end

// This protocol enables typed collections. i.e.:
// RLMArray<Backups *><Backups>
RLM_ARRAY_TYPE(Backups)

//
//  Backups.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//Copyright © 2020 石子涵. All rights reserved.
//

#import "Backups.h"

@implementation Backups

// Specify default values for properties

//+ (NSDictionary *)defaultPropertyValues
//{
//    return @{};
//}

// Specify properties to ignore (Realm won't persist these)

//+ (NSArray *)ignoredProperties
//{
//    return @[];
//}

@end

//
//  DetailView.h
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailView : UIView

@property(nonatomic,strong)UIImageView *imgBG;
@property(nonatomic,strong)UILabel *labelTitle;
@property(nonatomic,strong)UITextField *tfTitle;
@property(nonatomic,strong)UIImageView *ivContentBg;
@property(nonatomic,strong)UITextView *tvContent;
@property(nonatomic,strong)UIButton *btnSave;
@property(nonatomic,strong)UIButton *btnBack;
@property(nonatomic,strong)UIButton *btnDelete;


-(void)viewInit;
@end

NS_ASSUME_NONNULL_END

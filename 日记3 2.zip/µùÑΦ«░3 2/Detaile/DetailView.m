//
//  DetailView.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "DetailView.h"

@implementation DetailView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)viewInit{
    self.imgBG=[[UIImageView alloc]initWithFrame:self.frame];
       self.imgBG.image=[UIImage imageNamed:@"bg"];
       
       [self addSubview:self.imgBG];
    
          self.labelTitle = [[UILabel alloc]init];
          self.labelTitle.text = @"标题:";
          self.labelTitle.font = [UIFont systemFontOfSize:(15)];
    self.labelTitle.frame = CGRectMake(37,80,87,57);
          [self addSubview:self.labelTitle];
         
          self.tfTitle = [UITextField new];
          self.tfTitle.background = [UIImage imageNamed:@"输入框"];
          self.tfTitle.font = [UIFont systemFontOfSize:(15)];
    self.tfTitle.frame = CGRectMake(132, 89, 197, 39.5);
          [self addSubview:self.tfTitle];
         
          
          self.ivContentBg = [UIImageView new];
          self.ivContentBg.image = [UIImage imageNamed:@"输入框"];
          [self addSubview:self.ivContentBg];
  

          
          self.tvContent = [UITextView new];
          self.tvContent.font = [UIFont systemFontOfSize:(15)];
    self.tvContent.frame = CGRectMake(29, 159, 357, 568);
    self.tvContent.backgroundColor = [UIColor colorWithRed:arc4random()%225/255.0 green:arc4random()%225/255.0 blue:arc4random()%225/255.0 alpha:arc4random()%225/255.0];
          [self addSubview:self.tvContent];
        
       
          self.btnSave = [UIButton new];
          [self.btnSave setTitle:@"保存" forState:UIControlStateNormal];
          [self.btnSave setBackgroundColor:[UIColor blueColor]];
    self.btnSave.frame = CGRectMake(0, 753, 138, 109);
          [self addSubview:self.btnSave];
    
          self.btnBack = [UIButton new];
          [self.btnBack setTitle:@"取消" forState:UIControlStateNormal];
          [self.btnBack setBackgroundColor:[UIColor darkGrayColor]];
     self.btnBack.frame = CGRectMake(138, 753, 138, 109);
          [self addSubview:self.btnBack];
    
          self.btnDelete= [UIButton new];
          [self.btnDelete setTitle:@"删除" forState:UIControlStateNormal];
          [self.btnDelete setBackgroundColor:[UIColor lightGrayColor]];
          self.btnDelete.hidden = YES;
     self.btnDelete.frame = CGRectMake(276, 753, 138, 109);
          [self addSubview:self.btnDelete];
    
}
@end

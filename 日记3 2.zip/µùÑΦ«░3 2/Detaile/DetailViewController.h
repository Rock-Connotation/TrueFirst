//
//  DetailViewController.h
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailView.h"
#import "DetailModel.h"
#import "Backups.h"
#import "ToastView.h"
#import "TimeStamp.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : UIViewController

@property(nonatomic,assign)int sort;
@property(nonatomic, strong) NSString *date;
@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSString *content;


@end

NS_ASSUME_NONNULL_END

//
//  DetailViewController.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@property (nonatomic, strong) DetailView *detailview;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    self.detailview = [[DetailView alloc] initWithFrame:self.view.frame];
    [self.detailview viewInit];
    
    [self.detailview.btnSave addTarget:self action:@selector(saveAction) forControlEvents:UIControlEventTouchUpInside];
    [self.detailview.btnBack addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    [self.detailview.btnDelete addTarget:self action:@selector(deleteAction) forControlEvents:UIControlEventTouchUpInside];
    
    self.detailview.tfTitle.text = self.title;
    self.detailview.tvContent.text = self.content;
    
    [self.view addSubview:self.detailview];
    
    if(self.sort == 1)
        self.detailview.btnDelete.hidden = NO;
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)deleteAction{
    
    NSLog(@"delete");

    
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"date = %@",
                         self.date];
    RLMResults<Backups *> *backups = [Backups objectsWithPredicate:pred];
    RLMRealm *realm = [RLMRealm defaultRealm];
    [realm transactionWithBlock:^{
        Backups *backup = [backups objectAtIndex:0];
        [realm deleteObject:backup];
        
    }];
    [ToastView showToastView:self.view WithMessage:@"删除成功"];

    [self performSelector:@selector(cancelAction) withObject:nil afterDelay:2];
}
-(void)saveAction{
    
    NSString* title = self.detailview.tfTitle.text;
    NSString* content = self.detailview.tvContent.text;
    
    if([title isEqualToString:@""]||title==NULL){
        [ToastView showToastView:self.view WithMessage:@"标题没写"];
        return ;
    }
    
    if([content isEqualToString:@""]||content==NULL){
        [ToastView showToastView:self.view WithMessage:@"内容没写"];
        return ;
    }
    
    
    NSLog(@"save %@ %@",title,content);
    if(self.sort == 0){
        Backups *backup = [[Backups alloc]init];
        backup.date = [TimeStamp getCurrentTimeStemp];
        backup.title = self.detailview.tfTitle.text;
       backup.content = self.detailview.tvContent.text;
        
        RLMRealm *realm = [RLMRealm defaultRealm];
        [realm transactionWithBlock:^{
            [realm addObject:backup];
        }];
        
        [ToastView showToastView:self.view WithMessage:@"保存成功"];
        
    }else if(self.sort == 1){
        NSPredicate *pred = [NSPredicate predicateWithFormat:@"date = %@",
                             self.date];
        RLMResults<Backups *> *backups = [Backups objectsWithPredicate:pred];
        
        [[RLMRealm defaultRealm] transactionWithBlock:^{
            Backups *backup = [backups objectAtIndex:0];
            backup.date = [TimeStamp getCurrentTimeStemp];
            backup.title = self.detailview.tfTitle.text;
            backup.content = self.detailview.tvContent.text;

        }];
        [ToastView showToastView:self.view WithMessage:@"修改成功"];
        
        
    }

    
    [self performSelector:@selector(cancelAction) withObject:nil afterDelay:2];
}
-(void)cancelAction{
    NSLog(@"cancel");
    [self.navigationController popViewControllerAnimated:YES];
}



@end

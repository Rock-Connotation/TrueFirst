//
//  FirstTableViewCell.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "FirstTableViewCell.h"

@implementation FirstTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier
    {
        if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier])
        {
            self.labelTitle = [UILabel new];
            self.labelTitle.font =[UIFont systemFontOfSize:15];
            self.labelTitle.frame = CGRectMake(20, 11, 80, 20);
            [self addSubview:self.labelTitle];
            
            self.labelDate = [UILabel new];
            self.labelDate.font =[UIFont systemFontOfSize:15];
            self.labelDate.frame = CGRectMake(174, 11, 113, 20);
            [self addSubview:self.labelDate];
            
            self.labelBottom = [UILabel new];
            self.labelBottom.backgroundColor = [UIColor darkGrayColor];
            self.labelBottom.frame = CGRectMake(321, 11, 60, 20);
            [self addSubview:self.labelBottom];
        }
        return self;
    }

@end

//
//  FirstView.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "FirstView.h"

@implementation FirstView
-(void)viewInit{
    
    self.imgBG=[[UIImageView alloc]initWithFrame:self.frame];
    self.imgBG.image=[UIImage imageNamed:@"bg"];
    
    self.viwBacground = [[UIView alloc] initWithFrame:CGRectMake(0, 44, 414, 101)];
       self.viwBacground.backgroundColor = [UIColor colorWithRed:0 green:arc4random()%225/255.0 blue:arc4random()%225/255.0 alpha:0.5];
       [self addSubview:self.viwBacground];
    
    [self addSubview:self.imgBG];
   
    self.labelTitle = [[UILabel alloc]init];
    self.labelTitle.text = @"日记";
    self.labelTitle.font = [UIFont systemFontOfSize:17];
    self.labelTitle.frame = CGRectMake(133, 44, 110, 65);
    [self addSubview:self.labelTitle];
    

    
    self.btnAdd = [[UIButton alloc]init];
    [self.btnAdd setTitle:@"添加" forState:UIControlStateNormal ];
    [self.btnAdd setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.btnAdd.frame = CGRectMake(315, 52, 70, 34);
    [self addSubview:self.btnAdd];
;
    
    self.tableviewFirst = [[UITableView alloc]init];
   self.tableviewFirst.backgroundColor = [UIColor clearColor];
    self.tableviewFirst.frame = CGRectMake(0, 145, 414, 717);
    
    [self addSubview:self.tableviewFirst];

    
    self.labelLine = [UILabel new];
    self.labelLine.backgroundColor = [UIColor darkGrayColor];
    [self addSubview:self.labelLine];

}



@end

//
//  FirstViewController.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) FirstView *firstView;
@property (nonatomic, strong) FirstModel *model;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden=YES;
    self.navigationController.navigationBar.barStyle=UIBarStyleBlack;
    
    self.firstView = [[FirstView alloc]initWithFrame:self.view.frame];
    [self.firstView viewInit];
    
    [self.firstView.tableviewFirst setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    self.firstView.tableviewFirst.bounces=NO;
    self.firstView.tableviewFirst.delegate=self;
    self.firstView.tableviewFirst.dataSource=self;
    
    [self.firstView.btnAdd addTarget:self action:@selector(addAction) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.firstView];
    
    NSString* a =[TimeStamp getCurrentTimeStemp];
    NSLog(a);
}

-(void)addAction{
    
    DetailViewController* vc = [[DetailViewController alloc]init];
    vc.sort = 0;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.dataArray.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *cellIdentifier = [NSString stringWithFormat:@"MainTableViewCell%ld%ld", [indexPath section], [indexPath row]];
    FirstTableViewCell *cell = (FirstTableViewCell *)[theTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[FirstTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    Backups *backup = self.dataArray[indexPath.row];
    
    cell.labelTitle.text = backup.title;
    cell.labelDate.text = backup.date;
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
    
    
    self.dataArray = [NSMutableArray new];
    RLMResults *data = [[Backups allObjects] sortedResultsUsingKeyPath:@"date" ascending:NO];
    
    [[RLMRealm defaultRealm] transactionWithBlock:^{
        
        for (Backups *backup in data) {
            [self.dataArray addObject:backup];
        }
        
    }];
    
    [self.firstView.tableviewFirst reloadData];
    
    NSLog(@"%lu",(unsigned long)self.dataArray.count);
}

- (void)tableView:(UITableView *)theTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [theTableView deselectRowAtIndexPath:indexPath animated:YES];
    NSLog(@"selected %ld row", indexPath.row);
    
    DetailViewController* vc = [[DetailViewController alloc]init];
    vc.sort = 1;
    vc.date = ((Backups *)self.dataArray[indexPath.row]).date;
    vc.title = ((Backups *)self.dataArray[indexPath.row]).title;
    vc.content = ((Backups *)self.dataArray[indexPath.row]).content;
    [self.navigationController pushViewController:vc animated:YES];
    
    
}



@end

//
//  TimeStamp.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "TimeStamp.h"

@implementation TimeStamp

//获取当前的时戳
+(NSString *)getCurrentTimeStemp{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"YYYY年MM月dd日 HH:mm ss秒"];
    NSString *date =  [formatter stringFromDate:[NSDate date]];
    NSString *timeLocal = [[NSString alloc] initWithFormat:@"%@", date];
    return timeLocal;
}

//获取当前的时戳 毫秒
+(long)getCurrentTimeStamp{
    
    NSDate *date = [NSDate date];
    long timeStemp=(long)[date timeIntervalSince1970]*1000;
    NSLog(@"现在的时戳是：%ld",timeStemp);
    return timeStemp;
}


+(NSString *)timeStampToDate:(long)timeStemp{
    
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeStemp];
    //时间戳转换为当前时间
    NSDateFormatter *dateformatter = [[NSDateFormatter alloc] init];
    //HH为24小时制 hh为12小时制
    [dateformatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    NSString *currentTime = [dateformatter stringFromDate:date];
    return currentTime;
}


+(NSString*)timeToTimestamp:(NSString *)time{
    
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss:SSS"];
    
    
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    
    [formatter setTimeZone:timeZone];

    NSDate* date = [formatter dateFromString:time];
    
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue];
    
    NSString *Time=[NSString stringWithFormat:@"%ld",timeSp];
    
    NSLog(@"将某个时间转化成 时间戳&&&&&&&timeSp:%ld",(long)timeSp);
    return Time;
}


//当前时间戳转年月日
+(NSString *)getCurrentTimeStempChangeYMD{
    
    NSDate *data = [NSDate date];
    long timeStemp=(long)[data timeIntervalSince1970];
 
    
    NSDate*detaildate=[NSDate dateWithTimeIntervalSince1970:timeStemp];
    
    NSDateFormatter*dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy年MM月dd日"];
    
    NSString*currentDateStr = [dateFormatter stringFromDate:detaildate];
    return currentDateStr;

}


@end

//
//  ToastView.h
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ToastView : UIView

+(void)showToastView:(UIView *)uiview WithMessage:(NSString *)message;

+(void)showToastViewShort:(UIView *)uiview WithMessage:(NSString *)message;

+(void)showToastViewWithCostUpload:(UIView *)uiview WithMessage:(NSString *)message;

+(void)showSmallHeightToastView:(UIView *)uiview WithMessage:(NSString *)message;

@end

NS_ASSUME_NONNULL_END

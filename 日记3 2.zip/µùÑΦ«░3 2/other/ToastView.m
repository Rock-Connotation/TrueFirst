//
//  ToastView.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ToastView.h"

@implementation ToastView

//Toast提示框
+(void)showToastView:(UIView *)uiview WithMessage:(NSString *)message
{
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:.3];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [uiview addSubview:showview];
    UILabel *label = [[UILabel alloc]init];
    CGSize LabelSize = [message sizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(290, 9000)];
    label.frame = CGRectMake(10, 5, LabelSize.width, LabelSize.height);
    label.text = message;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = 1;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:25];
    [showview addSubview:label];
    showview.frame = CGRectMake((uiview.frame.size.width - LabelSize.width - 20)/2, uiview.frame.size.height - LabelSize.height-100, LabelSize.width+20, LabelSize.height+10);
    [UIView animateWithDuration:5.0 animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}

+(void)showToastViewShort:(UIView *)uiview WithMessage:(NSString *)message
{
    UIView *showview = [[UIView alloc]init];
    showview.backgroundColor = [UIColor whiteColor];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [uiview addSubview:showview];
    UILabel *label = [[UILabel alloc]init];
    CGSize LabelSize = [message sizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(290, 9000)];
    label.frame = CGRectMake(10, 5, LabelSize.width, LabelSize.height);
    label.text = message;
    label.textColor = [UIColor blackColor];
    label.textAlignment = 1;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:15];
    [showview addSubview:label];
    showview.frame = CGRectMake((uiview.frame.size.width - LabelSize.width - 20)/2, uiview.frame.size.height - LabelSize.height-60, LabelSize.width+20, LabelSize.height+10);
    [UIView animateWithDuration:1 animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}


+(void)showToastViewWithCostUpload:(UIView *)uiview WithMessage:(NSString *)message
{
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:.3];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [uiview addSubview:showview];
    UILabel *label = [[UILabel alloc]init];
    CGSize LabelSize = [message sizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(290, 9000)];
    label.frame = CGRectMake(10, 5, LabelSize.width, LabelSize.height);
    label.text = message;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = 1;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:25];
    [showview addSubview:label];
    showview.frame = CGRectMake((uiview.frame.size.width - LabelSize.width - 20)/2, uiview.frame.size.height - LabelSize.height-100, LabelSize.width+20, LabelSize.height+10);
    [UIView animateWithDuration:3.0 animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}


+(void)showSmallHeightToastView:(UIView *)uiview WithMessage:(NSString *)message
{
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:.3];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [uiview addSubview:showview];
    UILabel *label = [[UILabel alloc]init];
    CGSize LabelSize = [message sizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(290, 9000)];
    label.frame = CGRectMake(10, 0, LabelSize.width, LabelSize.height);
    label.text = message;
    label.textColor = [UIColor whiteColor];
    label.textAlignment = 1;
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont boldSystemFontOfSize:25];
    [showview addSubview:label];
    showview.frame = CGRectMake((uiview.frame.size.width - LabelSize.width - 20)/2, uiview.frame.size.height - LabelSize.height-60, LabelSize.width+20, LabelSize.height-5);
    [UIView animateWithDuration:5.0 animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}

@end

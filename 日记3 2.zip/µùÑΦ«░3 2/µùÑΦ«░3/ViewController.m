//
//  ViewController.m
//  日记3
//
//  Created by 石子涵 on 2020/2/23.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

@end
